<?php
header("content-Type: text/html; charset=utf-8"); //語言強制
phpinfo();
?>