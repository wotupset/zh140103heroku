恋は命の花だから
[こい]は[いのち]の[はな]だから
Koi wa inochi no hana dakara

咲かしてみせます紅に
[さかして]みせます[くれない]に
Sakashite misemasu kurenai ni

大和撫子ここにあり
[やまとなでしこ]ここにあり
Yamato nadeshiko koko ni ari

乙女の花道で歌います
[おとめ]の[はなみち]で[うたいます]
Otome no hanamichi de utaimasu

命燃やして恋せよ乙女
[いのち][もえ]やして[こいせよ][おとめ]
Inochi Moyashite Koiseyo Otome

//
今宵はんなり着飾って
[こよい]はんなり[きかざって]
Koyoi hannari kikazatte

あなたと歩くおんな坂
あなたと[あるく][おんなざか]
Anata to aruku onnazaka


弁天様の石段で
[べんてんさま]の[いしだん]で

よろけた時は抱き止めてね優しく
よろけた[とき]は[だきとめてね][やさしく]

焦れて焦れて
[じれて][じれて]
Anata to aruku onnazaka


恋心も上り坂
[こいこころ]も[のぼりざか]
Koigokoro mo noborizaka

梅の香り振り向いたら
[うめ]の[かおり][ふりむいら]
Ume no kaori furimuitara

紅い花が私に囁いた
[あかい][はな]が[わたし]に[ささやいた]
Akai hana ga watashi ni sasayaita

命燃やして恋せよ乙女
[いのち][もえ]やして[こいせよ][おとめ]
Inochi moyashite koiseyo otome

花の命は長いけど
[はな]の[いのち]は[]けど
Hana no inochi wa nagai kedo

命燃やして恋せよ乙女
[いのち][もえ]やして[こいせよ][おとめ]
Inochi moyashite koiseyo otome

心は駆け足
[こころ]は[かけあし]
Kokoro wa kakeashi



